Progress Indicator

Copyright (C) 2008-2010 Emilio Sim�es.
This project is licensed under the Code Project Open License.
<http://www.codeproject.com/info/cpol10.aspx>

